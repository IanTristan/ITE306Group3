<?php include "includes/config.php";

session_start();

if(isset($_SESSION['username'])){
$username = $_SESSION['username'];
 

    if($username){
        if(isset($_POST['change'])){
            $current_pass= mysqli_escape_string($con, $_POST['current_pass']);
            $new_pass = mysqli_escape_string($con,$_POST['psw']);
            $hash_password = password_hash($new_pass, PASSWORD_DEFAULT);
            //connect db


            $queryget = mysqli_query($con,"SELECT password FROM tbl_useraccounts WHERE employee_id = '$username'" ) or die (mysqli_error());
            $row = mysqli_fetch_assoc($queryget);
            $oldpassword = $row['password'];
            $current_hash = password_verify($current_pass, $oldpassword);

            //check pass

            if($current_pass == $current_hash){
                $querychange = mysqli_query($con,"UPDATE tbl_useraccounts SET password ='$hash_password' WHERE employee_id = '$username'");
                    if($querychange){
                        echo "<script>alert('Password has been changed!');document.location='HomeForAdmin.php'</script>";
                    }
            }
            else{
                echo '<script type="text/javascript">alert("Old password didnt match!");</script>';
            }
 
        }
    }
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>Malued Elementary School</title>
    
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.15.1/css/all.css" integrity="sha384-vp86vTRFVJgpjF9jiIGPEEqYqlDwgyBgEF109VFjmqGmIY/Y4HV4d3Gp2irVfcrp" crossorigin="anonymous">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.0/jquery.min.js"></script>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css" />
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>

    <style>
            p, li 
            { 
                line-height: 1.8; 
            }

            header 
            {
                background-image: linear-gradient(rgba(0, 0, 0, 0.5),rgba(0, 0, 0, 0.5)),url(helpme1.png);
                height: 100vh;
                background-size: cover;
                background-position: center;
            }

            .main-nav
            {
                float: right;
                list-style: none;
                margin-top: 30px;
            }

            .main-nav li
            {
                display: inline-block;
            }

            .main-nav li a
            {
                color: #f0f8ff;
                background-color: #151515;
                text-decoration: none;
                padding: 5px 20px;
                font-family: "Montserrat", sans-serif; 
                font-size: 15px;
                font-weight: bold;
            }

            .main-nav li.active a 
            {
                background: #f0f8ff;
                color: #151515;
                border: 2px solid #151515;
            }

            a:hover 
            {
                border: 2px solid #f0f8ff;
            }

            .main-nav li ul{
                margin: 0;
                padding: 0;
                list-style: none;
                position: absolute;
                float: left;
                display: none;
                background-color: #151515;
                width: 106px;
            }

            .main-nav li ul li{
                display: block;
                float: none;
                margin-bottom: 0px;
                padding: 0;
                margin: 0;
            }

            .main-nav li:hover ul{
                display: block;
            }

            .row 
            {
                max-width: 1200px;
                margin: auto;
            }

            .clearfix:after 
            {
                visibility: hidden;
                display: block;
                font-size: 0;
                content: " ";
                clear: both;
                height: 0;
            }

            .clearfix 
            { 
                display: inline-block; 
            }
                /* start commented backslash hack \*/
            * html .clearfix 
            { 
                height: 1%; 
            }
                
            .clearfix 
            { 
                display: block; 
            }

            body 
            {
                padding: 0px;
                margin: 0px;
                font-family: "Montserrat", sans-serif;
            }

            table 
            {
                position: absolute;
                left: 50%;
                top: 70%;
                transform: translate(-50%, -50%);
                border-collapse: collapse;
                width: 800px;
                height: 200px;
                border: 3px solid transparent;
                box-shadow: 2px 2px 12px rgba(0, 0, 0, 0.2), -1px -1px 8px rgba(0, 0, 0, 0.2);
                font-weight: bold;
                color: white;
            }

            .hero 
            {
                /*position: absolute;
                width: 1200px;*/
                border: none;
                color: white;
                text-align: center;
                text-decoration: none;
                display: inline-block;
                font-size: 16px;
                cursor: pointer;
            }

            .next
            {
               margin-bottom: 30px;
                padding: 12px;
                text-align: center;
                border-bottom: 1px solid #ddd;
                color: #f0f8ff;

            }

            .students
            {
                padding: 0;
                margin: 0;
                font-family: "Montserrat", sans-serif; 
                
            }

            .info
            {
                position: absolute;
                left: 50%;
                top: 35%;
                padding-bottom: 45%;
                transform: translate(-50%, -50%);
                border-collapse: collapse;
                width: 12%;
                height: 10%;
                border: 3px solid transparent;
                text-align: center;
                box-shadow: 2px 2px 12px rgba(0, 0, 0, 0.2) -1px -1px 8px rgba(0, 0, 0, 0.2);
                color: #f0f8ff;
                font-weight: bold;
            }

            tr 
            {
                transition: all .2s ease-in;
                cursor: pointer;
            }

            th,td 
            {
                padding: 12px;
                text-align: center;
                border-bottom: 1px solid #ddd;
                color: #f0f8ff;
            }

            #subject 
            {
                background-color: #151515;
                color: #f0f8ff;
                font-weight: bold;
            }

            #halp
            {
                background-color: #151515;
                color: #f0f8ff;
                font-weight: bold;
            }

            tr:hover 
            {
                background-color: #151515;
                transform: scale(1.02);
                box-shadow: 2px 2px 12px rgba(0, 0, 0, 0.2), -1px -1px 8px rgba(0, 0, 0, 0.2);
            }

            @media only screen and (max-width: 768px) 
            {
                table 
                {
                    width: 70%;
                }
            }

            .form-group
            {
                margin: 0;
                font-weight: bolder;
            }

            #left{
                float: left;
                width: 75px;
                overflow: hidden;
                padding-top: 10px;
            }


            #midname{
                margin-bottom: 10px;
            }

            #gradelevel{
                float: left;
                overflow: hidden;
            }

            input {
            width: 100%;
            padding: 12px;
            border: 1px solid #ccc;
            border-radius: 4px;
            box-sizing: border-box;
            margin-top: 6px;
            margin-bottom: 16px;
        }

        /* Style the submit button */
        input[type=submit] {
            background-color: #4CAF50;
            color: white;
        }

        /* Style the container for inputs */
        /*.container {
        background-color: #f1f1f1;
        padding: 20px;
        }
        */
        /* The message box is shown when the user clicks on the password field */

        #message {
            display:none;
            background: #f1f1f1;
            color: #000;
            position: relative;
            padding: 20px;
            margin-top: 10px;
        }

        #message p {
            padding: 10px 35px;
            font-size: 18px;
        }

        /* Add a green text color and a checkmark when the requirements are right */

        .valid {
            color: green;
        }

        .valid:before {
            position: relative;
            left: -35px;
            content: "✔";
        }

        /* Add a red text color and an "x" when the requirements are wrong */
        .invalid {
            color: red;
        }

        .invalid:before {
            position: relative;
            left: -35px;
            content: "✖";
        }
    </style>
</head>

<body>
    <header>
        <div id="main-header" class="row clearfix">
            <ul class="main-nav">
                <li>
                    <a href="HomeForAdmin.php"> Home </a>
                </li>

                <li>
                    <a href="studentsForAdmin.php"> Students </a>
                </li>

                <li class="active">
                    <a href="subjectsForAdmin.php"> Subjects </a>
                </li>

                <li>
                    <a data-toggle="modal" data-target="#myModal" href="#myModal" class="modal-btn"> Enroll Pupil </a>
                </li>

                <li>
                    <a href=""><?php
                              if(isset($_SESSION['first_name'])){
                                echo 'Welcome'.', '.$_SESSION['last_name'];
                              }
                            ?></a>
                    <ul>
                        <li style="padding-left: 6px; padding-bottom: 10px;"><a href="#">History</a></li>
                        <li style="padding-left: 1px; padding-bottom: 10px;"><a href="teachersForAdmin.php">Teachers</a></li>
                        <li style="padding-left: 10px; padding-bottom: 10px;"><a href="#">About</a></li>
                        <li style="padding-left: 2px; padding-bottom: 10px;"><a data-toggle="modal" data-target="#EditPassword" href="#EditPassword" class="modal-btn">Settings</a></li>
                        <li style="padding-left: 6px; padding-bottom: 10px;"><a href="logout.php?logout-submit=logout" name="logout"> Logout </a></li>
                    </ul>
                </li>
            </ul>
        </div>
    
        <div class="hero">
            <div class="students">
                <h1 style="position: absolute; left: 44%; top: 16%; color: white;">GRADE 6</h1>
                <table class="info">
                    <tr id="halp">
                        <td>
                            <a href="subjects4ForAdmin.php" style="color: #f0f8ff; font-size: larger;"> < </a>
                        </td>

                        <td>
                            <a href="#" style="color: #f0f8ff; font-size: larger;"> > </a>
                        </td>
                    </tr>
                </table>
            </div>
        </div>

        <div class="modal fade" id="myModal">
                <form action="EnrollmentForm.php" method="post">
                    <div class="modal-dialog" role="document">
                        <div class="modal-content" style="background-color: #151515; width: 130%; position: absolute; top: 15%; left: -15%;">
                            <div class="modal-header" style="border: 3px solid #f0f8ff;">
                                <center>
                                    <h1 style="color: #f0f8ff; font-weight: bold; font-family: 'Monsterrat',sans-serif;">Enrollment Form</h1>
                                </center>
                            </div>

                        <div class="modal-body" style="border: 2px solid #f0f8ff; overflow: auto;">
                            <div class="form-group">
                                <label style="color: #f0f8ff; font-family: 'Monsterrat',sans-serif; float: left; margin-left: 200px; margin-top: 5px; margin-right: 10px;">Learning Reference Number </label>
                                <input name="lrn" id="learnNum" type="text" class="form-control" style="text-align: center; width: 19%; font-family: 'Monsterrat',sans-serif; border: 3px solid #f0f8ff;" required>
                            </div>

                            <div class="form-group">
                                <label id="left" style="color: #f0f8ff; font-family: 'Monsterrat',sans-serif; margin-top: 5px;">First Name</label>
                                <input id="left" name="Fname" type="text" class="form-control" style="width: 13%; text-align: center; font-family: 'Monsterrat',sans-serif; border: 3px solid #f0f8ff; margin-top: 8px; font-size: medium; display: inline-block;" required>
                            </div>

                            <div class="form-group">
                                <label id="left" style="color: #f0f8ff;  font-family: 'Monsterrat',sans-serif; padding-left: 10px; width: 85px; margin-top: 5px;">Last Name</label>
                                <input id="left" name="Lname" type="text" class="form-control" style="width: 14%; text-align: center; font-family: 'Monsterrat',sans-serif; border: 3px solid #f0f8ff; margin-top: 8px; font-size: medium; display: inline-block;" required>
                            </div>

                            <div class="form-group">
                                <label id="left" style="color: #f0f8ff;  font-family: 'Monsterrat',sans-serif; margin-left: 10px; width: 90px; margin-top: 5px;">Middle Name</label>
                                <input id="left" name="Mname" type="text" class="form-control" style="width: 14%; text-align: center; font-family: 'Monsterrat',sans-serif; margin-left: 1px; border: 3px solid #f0f8ff; margin-top: 7px; font-size: medium; display: inline-block;" required>

                                <label id="left" style="color: #f0f8ff;  font-family: 'Monsterrat',sans-serif; margin-left: 10px; width: 110px; margin-top: 5px;">Extension Name</label>
                                <select name="extname" style="margin-top: 10px; margin-left: 2px; width: 7%; font-family: 'Monsterrat',sans-serif; border: 3px solid #f0f8ff; margin-top: 13px;">
                                    <option value="jr" style="font-family: 'Monsterrat',sans-serif;">Jr</option>
                                    <option value="III" style="font-family: 'Monsterrat',sans-serif;">III</option>
                                    <option value="IV" style="font-family: 'Monsterrat',sans-serif;">IV</option>
                                    <option value="NA" style="font-family: 'Monsterrat',sans-serif;">N/A</option>
                                </select>
                            </div>
                        </div>

                        <div class="modal-body" style="border: 2px solid #f0f8ff; overflow: auto;">
                            <div class="form-group" id="midname">
                                <label style="color: #f0f8ff;  font-family: 'Monsterrat',sans-serif; margin-left: 20px;">Grade Level</label>
                                <select name="gradelevel" style="margin-top: 13px; margin-left: 2px; width: 6%; font-family: 'Monsterrat',sans-serif; border: 3px solid #f0f8ff;">
                                    <option value="1" style="font-family: 'Monsterrat',sans-serif;">1</option>
                                    <option value="2" style="font-family: 'Monsterrat',sans-serif;">2</option>
                                    <option value="3" style="font-family: 'Monsterrat',sans-serif;">3</option>
                                    <option value="4" style="font-family: 'Monsterrat',sans-serif;">4</option>
                                    <option value="5" style="font-family: 'Monsterrat',sans-serif;">5</option>
                                    <option value="6" style="font-family: 'Monsterrat',sans-serif;">6</option>
                                </select>

                                <label style="color: #f0f8ff;  font-family: 'Monsterrat',sans-serif; margin-left: 15px;">Section</label>
                                <select name="section" style="margin-top: 13px; margin-left: 3px; width: 6%; font-family: 'Monsterrat',sans-serif; border: 3px solid #f0f8ff;">
                                    <option value="1" style="font-family: 'Monsterrat',sans-serif;">1</option>
                                    <option value="2" style="font-family: 'Monsterrat',sans-serif;">2</option>
                                    <option value="3" style="font-family: 'Monsterrat',sans-serif;">3</option>
                                    <option value="4" style="font-family: 'Monsterrat',sans-serif;">4</option>
                                </select>

                                <label style="color: #f0f8ff;  font-family: 'Monsterrat', sans-serif; margin-left: 20px;">Birthday</label>
                                <input type="date" name="bday" value="2020-11-25" min="1950-01-01" max="2021-11-25" style="font-family: 'Monsterrat', sans-serif; color: #151515; border: 3px solid #f0f8ff; width: 129px;">

                                <label style="color: #f0f8ff;  font-family: 'Monsterrat', sans-serif; margin-left: 8px;">Sex</label>
                                <select name="sex" style="margin-left: 1px; width: 11%; font-family: 'Monsterrat',sans-serif; border: 3px solid #f0f8ff;">
                                    <option value="male" style="font-family: 'Monsterrat',sans-serif;">Male</option>
                                    <option value="female" style="font-family: 'Monsterrat',sans-serif;">Female</option>
                                </select>

                                <label style="color: #f0f8ff;  font-family: 'Monsterrat', sans-serif; margin-left: 5px;">Age</label>
                                <input name="Age" type="text" style="width: 8%; text-align: center; font-family: 'Monsterrat', sans-serif; border: 3px solid #f0f8ff;" required>
                            </div>

                            <div class="form-group">
                                <label style="color: #f0f8ff;  font-family: 'Monsterrat', sans-serif; margin-left: 18px;">Zip Code</label>
                                <input name="Zip" type="text" style="width: 60px; text-align: center;font-family: 'Monsterrat', sans-serif; border: 3px solid #f0f8ff;" required>

                                <label style="color: #f0f8ff;  font-family: 'Monsterrat', sans-serif; margin-left: 10px;">Mother Tongue</label>
                                <select name="MotherTongue" style="font-family: 'Monsterrat', sans-serif; border: 3px solid #f0f8ff; width: 125px;">
                                    <option value="bikol" style="font-family: 'Monsterrat',sans-serif;">Bikol</option>
                                    <option value="cebuano" style="font-family: 'Monsterrat',sans-serif;">Cebuano</option>
                                    <option value="hiligaynon" style="font-family: 'Monsterrat',sans-serif;">Hiligaynon</option>
                                    <option value="ilocano" style="font-family: 'Monsterrat',sans-serif;">Ilocano</option>
                                    <option value="kapampangan" style="font-family: 'Monsterrat',sans-serif;">Kapampangan</option>
                                    <option value="pangasinan" style="font-family: 'Monsterrat',sans-serif;">Pangasinan</option>
                                    <option value="tagalog" style="font-family: 'Monsterrat',sans-serif;">Tagalog</option>
                                    <option value="waray" style="font-family: 'Monsterrat',sans-serif;">Waray</option>
                                </select>

                                <label style="color: #f0f8ff;  font-family: 'Monsterrat',sans-serif; margin-top: 10px; margin-left: 5px;">Address</label>
                                <input name="lugar" type="text" class="form-control" style="width: 35%; text-align: center; float: right; font-family: 'Monsterrat',sans-serif; margin-right: 17px; border: 3px solid #f0f8ff;" required>
                            </div>
                        </div>

                        <div class="modal-body" style="border: 2px solid #f0f8ff; overflow: auto;">
                            <div class="form-group">
                                <center><h1 style="color: #f0f8ff; font-family: 'Monsterrat', sans-serif;">PARENT / GUARDIAN INFORMATION</h1></center>

                                <label style="color: #f0f8ff;  font-family: 'Monsterrat',sans-serif; margin-top: 9px; float: left; margin-left: 20px; margin-right: 5px;">Mothers Name</label>
                                <input id="mudra" name="MotherName" type="text" class="form-control" style="text-align: center; width: 30%; font-family: 'Monsterrat',sans-serif; border: 3px solid #f0f8ff; margin: 0; padding: 0; display: inline;" required>

                                <label style="color: #f0f8ff;  font-family: 'Monsterrat',sans-serif; margin-top: 9px; margin-left: 25px; margin-right: 0px;">Fathers Name</label>
                                <input name="FatherName" type="text" class="form-control" style="text-align: center; width: 30%; font-family: 'Monsterrat',sans-serif; border: 3px solid #f0f8ff; margin: 0; padding: 0; display: inline;" required>
                            </div>

                            <div class="form-group" style="margin-top: 10px;">
                                <label style="color: #f0f8ff;   font-family: 'Monsterrat',sans-serif; margin-top: 9px; float: left; margin-left: 110px; margin-right: 5px;">Telephone Number</label>
                                <input name="TeleNumber" type="text" class="form-control" style="text-align: center; width: 15%; font-family: 'Monsterrat',sans-serif; border: 3px solid #f0f8ff; margin: 0; padding: 0; display: inline;" required>

                                <label style="color: #f0f8ff;  font-family: 'Monsterrat',sans-serif; margin-top: 9px; margin-left: 25px;">Cellphone Number</label>
                                <input name="CellNumber" type="text" class="form-control" style="text-align: center; width: 15%; font-family: 'Monsterrat',sans-serif; border: 3px solid #f0f8ff; margin: 0; padding: 0; display: inline;" required>
                            </div>
                        </div>

                        <div class="modal-footer" style="border: 3px solid #f0f8ff;">
                            <button name="Enroll" type="submit" style="font-weight: bold; background-color: transparent; color: #f0f8ff; border: 3px solid #151515; font-size: larger; font-family: 'Monsterrat', sans-serif; margin-bottom: 4px; margin-right: 25px;">E N R O L L</button>
                            <button type="button" data-dismiss="modal" class="close" style="font-weight: bold; background-color: transparent; color: #f0f8ff; border: 3px solid #151515; text-decoration: none;">CLOSE</button>
                        </div>
                    </div>
                </div>
            </form>
        </div>

        <div class="container">
                <table>
                    <tr id="subject">
                        <th>Subjects</th>
                        <th>Time of Class</th>
                        <th>Assigned Teachers</th>
                        <th>Schedule</th>
                    </tr>

                    <tr>
                        <td>Subject 1</td>
                        <td>1:00 PM - 2:00 PM</td>
                        <td>Acela Callejo</td>
                        <td>Mon/Tue/Wed/Thu/Fri</td>

                    </tr>

                    <tr>
                        <td>Subject 2</td>
                        <td>2:00 PM - 3:00 PM</td>
                        <td>Amado Acuin</td>
                        <td>Mon/Tue/Wed/Thu/Fri</td>

                    </tr>

                    <tr>
                        <td>Subject 3</td>
                        <td>3:00 PM - 4:00 PM</td>
                        <td>Rosabella Sistoso</td>
                        <td>Mon/Tue/Wed/Thu/Fri</td>

                    </tr>

                    <tr>
                        <td>Subject 4</td>
                        <td>4:00 PM - 5:00 PM</td>
                        <td>Vilma Maramba</td>
                        <td>Mon/Tue/Wed/Thu/Fri</td>
                    </tr>
                </table>
            </div>
    </header>
</body>
</html>

<div class="modal fade" id="EditPassword">
    <form action="" method="post">
        <div class="modal-dialog" role="document">
            <div class="modal-content" style="background-color: #151515; width: 130%; position: absolute; top: 15%; left: -15%;">
                <div class="modal-header" style="border: 3px solid #E4008A;">
                    <center>
                        <h1 style="color: #E4008A; font-weight: bold; font-family: 'Monsterrat',sans-serif;">Change Password</h1>
                    </center>
                </div>

                <div class="modal-body" style="border: 2px solid #E4008A; overflow: auto;">
                    <form method="POST" class="form-body">
                        <div>
                            <div class="form-group" style="display: inline-block; color: #E4008A;">
                                <label style="float: left; margin-left: 200px; margin-top: 10px; margin-right: 5px; font-family: 'Monsterrat', sans-serif;">Current Password</label>
                                <input type="password" name="current_pass" class="form-control" style="width: 30%;">
                            </div>
                        </div>

                        <div>
                            <div class="form-group" style="display: inline-block; color: #E4008A;">
                                <label style="float: left; margin-left: 200px; margin-top: 10px; margin-right: 26px; font-family: 'Monsterrat', sans-serif;">New Password</label>
                                <input type="password" id="psw" name="psw" pattern="(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{8,}" title="Must contain at least one number and one uppercase and lowercase letter, and at least 8 or more characters" required style="width: 30%; padding: 6px; padding-left: 10px;">
                            </div>

                            <div class="form-group" align="center">
                                <input class="btn btn-primary" type="submit" name="change" value ="Save Changes">
                            </div>

                            <div id="message">
                                <h6>Password must contain the following:</h6>
                                <p style="background-color: white;" id="letter" class="invalid">A <b>lowercase</b> letter</p>
                                <p style="background-color: white;" id="capital" class="invalid">A <b>capital (uppercase)</b> letter</p>
                                <p style="background-color: white;" id="number" class="invalid">A <b>number</b></p>
                                <p style="background-color: white;" id="length" class="invalid">Minimum <b>8 characters</b></p>
                            </div>

                            <script>
                                var myInput = document.getElementById("psw");
                                var letter = document.getElementById("letter");
                                var capital = document.getElementById("capital");
                                var number = document.getElementById("number");
                                var length = document.getElementById("length");

                                // When the user clicks on the password field, show the message box

                                myInput.onfocus = function() {
                                    document.getElementById("message").style.display = "block";
                                }

                                // When the user clicks outside of the password field, hide the message box

                                myInput.onblur = function() {
                                    document.getElementById("message").style.display = "none";
                                }

                                // When the user starts to type something inside the password field
                                myInput.onkeyup = function() {
                                // Validate lowercase letters
                                var lowerCaseLetters = /[a-z]/g;
                                if(myInput.value.match(lowerCaseLetters)) {  
                                    letter.classList.remove("invalid");
                                    letter.classList.add("valid");
                                }

                                else {
                                    letter.classList.remove("valid");
                                    letter.classList.add("invalid");
                                }

                                // Validate capital letters
                                var upperCaseLetters = /[A-Z]/g;
                                if(myInput.value.match(upperCaseLetters)) {  
                                    capital.classList.remove("invalid");
                                    capital.classList.add("valid");
                                } 

                                else {
                                    capital.classList.remove("valid");
                                    capital.classList.add("invalid");
                                }

                                // Validate numbers
                                var numbers = /[0-9]/g;
                                if(myInput.value.match(numbers)) {  
                                    number.classList.remove("invalid");
                                    number.classList.add("valid");
                                } 

                                else {
                                    number.classList.remove("valid");
                                    number.classList.add("invalid");
                                }

                                // Validate length
                                if(myInput.value.length >= 8) {
                                    length.classList.remove("invalid");
                                    length.classList.add("valid");
                                } 

                                else {
                                    length.classList.remove("valid");
                                    length.classList.add("invalid");
                                }
                            }
                        </script>
                    </div>
                </form>
            </div>
        </div>
    </div>
</form>
</div>