<html>

<head>
    <title>Malued Elementary School</title>
    <link href="memereview.css" rel="stylesheet" type="text/css">

</head>

<body>
    <header>
        <section>
        <div id="main-header" class="row clearfix">
            <div class="logo">
                <img src="iicon.png">
            </div>
            <ul class="main-nav">
                <li>
                    <a href="home.php"> Home </a>
                </li>

                <li>
                    <a href="students.php"> Students </a>
                </li>

                <li>
                    <a href="subjects.php"> Subjects </a>
                </li>

                <li class="active">
                    <a href="about.php"> About </a>
                </li>
            </ul>
    
        </div>
    
        <div class="hero">
            <div class="container">
                
                <h1 id="masthead-text">MALUED ELEMENTARY SCHOOL</h1>
                <div class="button ">
                    <a href="history.php" target="_blank" class="btn btn-one "> History </a>
                    <a href="teachers.php" target="_blank" class="btn btn-two "> Teachers </a>
                </div>  

                <br/>       

            </div>
        </div>
        </section>
     </header>

     <div id="intro">
        <section>
        <div class="kappa">
            <section data-id="u2zrec3" class="elementor-element elementor-element-u2zrec3 elementor-section-full_width elementor-section-height-default elementor-section-height-default elementor-section elementor-top-section" data-element_type="section">
                        <div class="elementor-container elementor-column-gap-default">
                <div class="elementor-row">
                <div data-id="ued1cx9" class="elementor-element elementor-element-ued1cx9 elementor-column elementor-col-100 elementor-top-column" data-element_type="column">
            <div class="elementor-column-wrap elementor-element-populated">
                    <div class="elementor-widget-wrap">
                <section data-id="tcupx6c" class="elementor-element elementor-element-tcupx6c elementor-section-boxed elementor-section-height-default elementor-section-height-default elementor-section elementor-inner-section" data-element_type="section">
                        <div class="elementor-container elementor-column-gap-default">
                <div class="elementor-row">
                <div data-id="3rzq83w" class="elementor-element elementor-element-3rzq83w elementor-column elementor-col-50 elementor-inner-column" data-element_type="column">
            <div class="elementor-column-wrap elementor-element-populated">
                    <div class="elementor-widget-wrap">
                <div data-id="nykyg9t" class="elementor-element elementor-element-nykyg9t elementor-widget elementor-widget-text-editor" data-element_type="text-editor.default">
                <div class="elementor-widget-container">
                    <div class="elementor-text-editor elementor-clearfix">
                        <div class="lgc-column lgc-grid-parent lgc-grid-50 lgc-tablet-grid-50 lgc-mobile-grid-100 lgc-equal-heights lgc-first">
                            <div class="inside-grid-column ">
                                <p>
                                    <strong>VISION
                                        <br> 
                                    </strong>
                                    We dream of Filipinos who passionately love their country and whose values and competencies enable them to realize their full potential and contribute meaningfully to building the nation.
                                </p>
                                
                                <p>
                                    As a learner-centered public institution, the Department of Education continuosly improves itself to better serve its stakeholders.
                                </p>
                                
                                <p>
                                    <strong>MISSION
                                        <br>
                                    </strong> 
                                    <strong>T</strong>o protect and promote the right of every Filipino to quality, equitable, culture-based, and complete basic education where:
                                </p>
                                
                                <p>
                                    <strong>Strong </strong> learn in a child-friendly, gender-sensitive, safe, and motivating environment.
                                    <br>
                                </p>
                                
                                <p>
                                    <strong>Teachers </strong> facilitate learning and constantly nurture every learner.
                                    <br>
                                </p>
                                
                                <p>
                                    <strong>Administrators and staffs,</strong> as stewards of the institution, ensure an enabling and supportive environment for effective learning to happen.
                                    <br>
                                </p>
                                
                                <p>
                                    <strong>Family, community, and other stakeholders</strong> are actively engaged and share responsibility for developing life-long learners.
                                </p>
                                
                                <p>
                                    <strong>CORE VALUES</strong>
                                    <br>
                                    
                                    <strong style="font-style: italic">&nbsp; &nbsp; &nbsp;Maka-</strong>Diyos
                                    <br>
                                
                                    <strong style="font-style: italic">&nbsp; &nbsp; &nbsp;Maka-</strong>Tao
                                    <br> 
                                
                                    <strong style="font-style: italic">&nbsp; &nbsp; &nbsp;Makakalikasan</strong>
                                    <br>
                                
                                    <strong style="font-style: italic">&nbsp; &nbsp; &nbsp;Makabansa</strong>
                                    <br> 
                                </p>   
                            </div>
                        </div>
                    </div>
                </div>
                </div>
                 </div>
            </div>
        </div>
                    <div data-id="vgtfkl1" class="elementor-element elementor-element-vgtfkl1 elementor-column elementor-col-50 elementor-inner-column" data-element_type="column">
                    <div class="elementor-column-wrap elementor-element-populated">
                <div class="elementor-widget-wrap">
                <div data-id="0w8upfd" class="elementor-element elementor-element-0w8upfd elementor-widget elementor-widget-text-editor" data-element_type="text-editor.default">
                    <div class="elementor-widget-container">
                        <div class="elementor-text-editor elementor-clearfix">
                            <p>
                                <strong>
                                    GOALS
                                    <br>
                                </strong>
                                
                                <strong>
                                Malued Elementary School endeavors to pursue the goal of:
                                </strong>
                                <br>
                                
                                <strong>The goal of basic education is to provide the school age population and young adults with skills, knowledge, and values to become caring, self-reliant, productive and patriotic citizens. According to legislation, primary education is free and compulsory for children aged 7-12.
                                </strong>
                            </p>
                        </div>
                        
                    </div>
                </div>
                </div>
            </div>
        </div>
                        </div>
            </div>
              </section>
                </div>
            </div>
        </div>
                        </div>
            </div>
        </section>

    </div>
         </section>
     </div>
    
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <style>
        img 
        { 
            border-radius: 75%;
        }
    </style>               
<!-- Team Section -->

<!-- Team Section end-->

</body>
</html>