<?php
include "includes/config.php";
$lrn = mysqli_real_escape_string($con,$_POST['lrn']);
$lastname =  mysqli_real_escape_string($con,$_POST['Lname']);
$firstname = mysqli_real_escape_string($con,$_POST['Fname']);
$middlename = mysqli_real_escape_string($con,$_POST['Mname']);
$extenionname = mysqli_real_escape_string($con,$_POST['extname']);
$birthday = mysqli_real_escape_string($con,$_POST['bday']);
$gradelvl = mysqli_real_escape_string($con,$_POST['gradelevel']);
$section = mysqli_real_escape_string($con,$_POST['section']);

$sex =  mysqli_real_escape_string($con,$_POST['sex']);
$age =  mysqli_real_escape_string($con,$_POST['Age']);
$mothertongue = mysqli_real_escape_string($con,$_POST['MotherTongue']);
$address =  mysqli_real_escape_string($con,$_POST['lugar']);
$zipcode = mysqli_real_escape_string($con,$_POST['Zip']);
$mothername = mysqli_real_escape_string($con,$_POST['MotherName']);
$fathername =  mysqli_real_escape_string($con,$_POST['FatherName']);
$telephonenumber = mysqli_real_escape_string($con,$_POST['TeleNumber']);
$cellphonenumber = mysqli_real_escape_string($con,$_POST['CellNumber']);

$insert = "INSERT INTO tbl_students (LRN, LastName, FirstName, MiddleName, ExtentionName, Birthday, Section, GradeLevel, Sex, Age, MotherTongue, Address, ZipCode, MotherName, FatherName, TelephoneNumber, CellphoneNumber) VALUES ('$lrn','$lastname', '$firstname', '$middlename', '$extenionname', '$birthday','$gradelvl','$section', '$sex','$age', '$mothertongue', '$address', '$zipcode', '$mothername', '$fathername', '$telephonenumber', '$cellphonenumber');";
$query_run = mysqli_query($con,$insert);
	if ($query_run) {
   		
   			  echo "<script>alert('New Student Has Been Enrolled!');document.location='HomeForSuperAdmin.php'</script>";

		}
		else{
			echo '<script> alert("ERROR HAS OCCURED"); </script>';
		}
	
?>