<?php
	include('conn.php');
	
	$employee_id = mysqli_real_escape_string($conn,$_POST['UserID']);
		$last_name = mysqli_real_escape_string($conn,$_POST['Lname']);
		$first_name = mysqli_real_escape_string($conn,$_POST['Fname']);
		$passwordhash = password_hash(strtoupper($last_name), PASSWORD_DEFAULT);

		

		$query = "INSERT INTO tbl_useraccounts (employee_id, password, usertype, FirstName, LastName)
	VALUES ('$employee_id','$passwordhash','Admin','$first_name', '$last_name')";
		$query_run = mysqli_query($conn,$query);


		if ($query_run) {
   		
   			  echo "<script>alert('Account Has Been Updated!');document.location='HomeForSuperAdmin.php'</script>";

		}
		else{
			echo '<script> alert("ERROR HAS OCCURED"); </script>';
		}

?>