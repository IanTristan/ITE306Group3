<?php
include "includes/config.php";

session_start();
if(isset($_POST['loginbutton'])){

    $username = $_POST['username'];
    $password = $_POST['password'];
    $usertype = $_POST['usertype'];

    if ($username != "" && $password != ""){
       
        $sql_query = "SELECT * FROM tbl_useraccounts WHERE employee_id='".$username."' and password='".$password."' and usertype='".$usertype."'";
        $result = mysqli_query($con,$sql_query);
        while ($row=mysqli_fetch_array($result)) {
            if ($row['employee_id']==$username && $row['password']==$password && $row['usertype']=='Admin'){
                $_SESSION['username'] = $_POST['username'];
              header('location: home.php');
            }
            elseif ($row['employee_id']==$username && $row['password']==$password && $row['usertype']=='SuperAdmin') {
               $_SESSION['username'] = $_POST['username'];
               header('location: HomeForSuperAdmin.php');
            }      
}
}
    else{
          $message = "Please enter your credentials";
            echo "<script type='text/javascript'>alert('$message');</script>";
    }
}


?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<link rel="stylesheet" type="text/css" href="ITE233_IanCayabyab\bootstrap\css\bootstrap.min.css">
	<title>Login form design</title>
	<style>
		*{
			margin: 0;
			padding: 0;
			box-sizing: border-box;
		}

		body{
			min-height: 100vh;
			background: #2f3640;
			display: flex;
			font-family: sans-serif;
		}

		.container{
			margin: auto;
			width: 500px;
			max-width: 90%;
		}

		.container form{
			width: 100%;
			height: 100%;
			padding: 20px;
			background: #2f3640;
			border-radius: 4px;
			box-shadow: 0 8px 16px rgba(0,0,0,.6);
		}

		.container form h1{
			text-align: center;
			margin-bottom: 24px;
			color: #f0f8ff;
		}

		.container form .form-control{
			width: 100%;
			height: 40px;
			background: white;
			border-radius: 4px;
			border: 1px solid silver;
			margin: 10px 0 10px 0;
			padding: 0 10px;
		}

		.container form .btn{
			margin-left: 50%;
			transform: translateX(-50%);
			width: 120px;
			height: 34px;
			border: none;
			outline: none;
			background: #f0f8ff;
			font-family: 'Monsterrat', sans-serif;
			cursor: pointer;
			font-size: 16px;
			text-transform: uppercase;
			color: #151515;
			border-radius: 4px;
			transition: .3s;
		}

		.container form .btn:hover{
			opacity: .7
		}
		
	</style>
</head>
<body>
	<div class="container">
		<form action="" method="post">
			<h1>Login Form</h1>
			<div class="form-group">
				<label style="color: #f0f8ff; font-weight: bold;">Email ID</label>
				<input name="username" type="text" class="form-control" required>
			</div>

			<div class="form-group">
				<label for="" style="color: #f0f8ff; font-weight: bold;">Password</label>
				<input name="password" type="password" class="form-control" required>
			</div>

			<div class="form-group">
				<center>
					<label for="" style="color: #f0f8ff; font-weight: bold;">User Type</label>
					<select name="usertype">
						<option value="SuperAdmin">Super Admin</option>
						<option value="Admin">Admin</option>
					</select>
				</center>
			</div>
			<br>
            
            <button href="home.php" name="loginbutton" class="btn" type="submit">LOGIN</button>

		</form>
	</div>
</body>
</html>