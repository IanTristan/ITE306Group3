<?php
	include('includes/config.php');
	$id=$_GET['id'];
	mysqli_query($con,"DELETE FROM tbl_subjects where id='$id'");
	header('location:teachers.php');

?>