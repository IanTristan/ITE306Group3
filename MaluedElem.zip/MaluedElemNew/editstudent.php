<?php
	include "includes/config.php";
	
	/*$id=$_GET['id'];
*/	$roll = mysqli_real_escape_string($con,$_POST['RollNumber']);	
	$lrn = mysqli_real_escape_string($con,$_POST['lrn']);
	$lastname =  mysqli_real_escape_string($con,$_POST['Lname']);
	$firstname = mysqli_real_escape_string($con,$_POST['Fname']);
	$middlename = mysqli_real_escape_string($con,$_POST['Mname']);
	$extenionname = mysqli_real_escape_string($con,$_POST['extname']);
	$birthday = mysqli_real_escape_string($con,$_POST['bday']);
	$gradelvl = mysqli_real_escape_string($con,$_POST['gradelevel']);
	$section = mysqli_real_escape_string($con,$_POST['section']);
	$sex =  mysqli_real_escape_string($con,$_POST['sex']);
	$age =  mysqli_real_escape_string($con,$_POST['Age']);
	$mothertongue = mysqli_real_escape_string($con,$_POST['MotherTongue']);
	$address =  mysqli_real_escape_string($con,$_POST['lugar']);
	$zipcode = mysqli_real_escape_string($con,$_POST['Zip']);
	$mothername = mysqli_real_escape_string($con,$_POST['MotherName']);
	$fathername =  mysqli_real_escape_string($con,$_POST['FatherName']);
	$telephonenumber = mysqli_real_escape_string($con,$_POST['TeleNumber']);
	$cellphonenumber = mysqli_real_escape_string($con,$_POST['CellNumber']);


		

		$query = "UPDATE tbl_students SET LRN= '$lrn', LastName= '$lastname', FirstName= '$firstname', MiddleName= '$middlename', ExtentionName= '$extenionname', Section= '$section', GradeLevel= '$gradelvl', Birthday= '$birthday', Sex= '$sex', Age= '$age', MotherTongue= '$mothertongue', Address= '$address', ZipCode= '$zipcode', MotherName= '$mothername', FatherName= '$fathername', TelephoneNumber= '$telephonenumber', CellphoneNumber= '$cellphonenumber', WHERE NumberID='$roll'";
		$query_run = mysqli_query($con,$query);
		

		if ($query) {
   		
   			  echo "<script>alert('Student Information Has Been Updated!');document.location='StudentsForAdmin.php'</script>";

		}
		else{
			echo '<script> alert("ERROR HAS OCCURED"); </script>';
		}

?>