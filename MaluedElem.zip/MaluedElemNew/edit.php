<?php
	include('conn.php');
	
	$id=$_GET['id'];
	
		$employee_id = mysqli_real_escape_string($conn,$_POST['UserID']);
		$first_name = mysqli_real_escape_string($conn,$_POST['Fname']);
		$last_name = mysqli_real_escape_string($conn,$_POST['Lname']);
		$passwordhash = password_hash(strtoupper($last_name),PASSWORD_DEFAULT);

		$query = " UPDATE tbl_useraccounts SET FirstName='".$first_name."',LastName='".$last_name."', password = '".$passwordhash."' where employee_id='".$id."'";
				$query_run = mysqli_query($conn,$query);


		if ($query_run) {
   		
   			  echo "<script>alert('Account Has Been Updated!');document.location='UserAccounts.php'</script>";

		}
		else{
			echo '<script> alert("ERROR HAS OCCURED"); </script>';
		}

?>