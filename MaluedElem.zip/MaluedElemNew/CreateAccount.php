
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<link rel="stylesheet" type="text/css" href="C:\xampp\htdocs\MaluedElem\bootstrap\css\bootstrap.min.css">
	<link rel="stylesheet" type="text/css" href="CreateAccount.css">
	<link rel="stylesheet" type="text/css" href="memereview.css">
	<title>Create Account</title>
</head>
<body>
	<div id="main-header" class="row clearfix">
            <ul class="main-nav">
                <li class="active">
                	<a href="HomeForSuperAdmin.php"> Home </a>
                </li>

                <li>
                	<a href="students.php"> Students </a>
                </li>

                <li>
			        <a href="subjects.php"> Subjects </a>
			    </li>

			    <li>
			    	<a href="EnrollForm.php"> Enroll Pupil </a>
			    </li>

			    <li>
			    	<a href="CreateAccount.php"> Create Accounts </a>
			    </li>

			    <li>
			    	<a href="about.php"> About </a>
			    </li>
			</ul>
		</div>


	<div class="container">
		<form action="" method="POST">
			<h1>Create Account</h1>
			<div class="form-group">
				<label for="" style="color: #E4008A; font-weight: bold;">User ID</label>
				<input name="UserID" type="text" class="form-control" required>
			</div>


			<div class="form-group">
				<label style="color: #E4008A; font-weight: bold;">First Name</label>
				<input name="Fname" type="text" class="form-control" required>
			</div>

			<div class="form-group">
				<label for="" style="color: #E4008A; font-weight: bold;">Last Name</label>
				<input name="Lname" type="text" class="form-control" required>
			</div>

			
			<br>

			<div class="btn-toolbar" style="padding-left: 150px;">
				<button name="register" class="btn" type="submit" style="width: 154px; font-weight: bold;">Create</button>
				<button href="home.php" name="BackButton" class="btn" >Back</button>
			</div>
		</form>

	</div>
	

</body>
</html>
<?php   
include "includes/config.php";

if (isset($_POST['register'])) {

		$employee_id = mysqli_real_escape_string($con,$_POST['UserID']);
		$last_name = mysqli_real_escape_string($con,$_POST['Lname']);
		$first_name = mysqli_real_escape_string($con,$_POST['Fname']);
		$passwordhash = password_hash(strtoupper($last_name), PASSWORD_DEFAULT);

		

		$query = "INSERT INTO tbl_useraccounts (employee_id, password, usertype, FirstName, LastName)
	VALUES ('$employee_id','$passwordhash','Admin','$first_name', '$last_name')";
		$query_run = mysqli_query($con,$query);


		if ($query_run) {
   		
   			  echo "<script>alert('New Admin has been created!');document.location='HomeForSuperAdmin.php'</script>";

		}
		else{
			echo '<script> alert("ERROR HAS OCCURED"); </script>';
		}
	}
?>