<?php include "includes/config.php"; ?>
<!-- Delete -->
    <div class="modal fade" id="delstudent<?php echo $row['LRN']; ?>" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                    <center><h4 class="modal-title" id="myModalLabel">Delete</h4></center>
                </div>
                <div class="modal-body">
				<?php
					$del=mysqli_query($con,"select * from tbl_students where LRN='".$row['LRN']."'");
					$drow=mysqli_fetch_array($del);
				?>
				<div class="container-fluid">
					<h5><center>User Id: <strong><?php echo $drow['LRN']; ?></strong></center></h5> 
                </div> 
				</div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-default" data-dismiss="modal"><span class="glyphicon glyphicon-remove"></span> Cancel</button>
                    <a href="deletestudent.php?id=<?php echo $row['LRN']; ?>" class="btn btn-danger"><span class="glyphicon glyphicon-trash"></span> Delete</a>
                </div>
				
            </div>
        </div>
    </div>
<!-- /.modal -->
<!-- Edit -->
    <div class="modal fade" id="editstudent<?php echo $row['LRN']; ?>" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                    <center><h4 class="modal-title" id="myModalLabel">Edit</h4></center>
                </div>
                <div class="modal-body">
                <?php
                    $edit=mysqli_query($con,"select * from tbl_students where LRN='".$row['LRN']."'");
                    $erow=mysqli_fetch_array($edit);
                ?>

                <div class="container-fluid">
                <form method="POST" action="editstudent.php?id=<?php echo $erow['LRN']; ?>">
                    <div class="row">
                        <div class="col-lg-4">
                            <label style="position:relative; top:7px;">LRN</label>
                        </div>
                        <div class="col-lg-10">
                            <input type="hidden" name="RollNumber" value="<?php echo $row['NumberID']; ?>">
                            <input type="text" name="lrn" class="form-control" value="<?php echo $erow['LRN']; ?>">
                        </div>
                    </div>
                    <div style="height:10px;"></div>
                    <div class="row">
                        <div class="col-lg-4">
                            <label style="position:relative; top:7px;">First Name:</label>
                        </div>
                        <div class="col-lg-10">
                            <input type="text" name="Fname" class="form-control" value="<?php echo $erow['FirstName']; ?>">
                        </div>
                    </div>
                    <div style="height:10px;"></div>
                    
                    <div class="row">
                        <div class="col-lg-4">
                            <label style="position:relative; top:7px;">Last Name:</label>
                        </div>
                        <div class="col-lg-10">
                            <input type="text" name="Lname"  class="form-control" value="<?php echo $erow['LastName']; ?>">
                        </div>
                        <div style="height:10px;"></div>
                    
                    <div class="row">
                        <div class="col-lg-4">
                            <label style="position:relative; top:7px;">Middle Name:</label>
                        </div>
                        <div class="col-lg-10">
                            <input type="text" name="Mname"  class="form-control" value="<?php echo $erow['MiddleName']; ?>">
                        </div>
                        <div style="height:10px;"></div>
                    
                    <div class="row">
                        <div class="col-lg-4">
                            <label style="position:relative; top:7px;">Extention Name:</label>
                        </div>
                        <div class="col-lg-10">
                            <input type="text" name="extname"  class="form-control" value="<?php echo $erow['ExtentionName']; ?>">
                        </div>
                        <div style="height:10px;"></div>
                    
                    <div class="row">
                        <div class="col-lg-4">
                            <label style="position:relative; top:7px;">Section:</label>
                        </div>
                        <div class="col-lg-10">
                            <input type="text" name="section"  class="form-control" value="<?php echo $erow['Section']; ?>">
                        </div>
                        <div style="height:10px;"></div>

                    <div class="row">
                        <div class="col-lg-4">
                            <label style="position:relative; top:7px;">Grade Level:</label>
                        </div>
                        <div class="col-lg-10">
                            <input type="text" name="gradelevel"  class="form-control" value="<?php echo $erow['GradeLevel']; ?>">
                        </div>
                        <div style="height:10px;"></div>

                    <div class="row">
                        <div class="col-lg-4">
                            <label style="position:relative; top:7px;">Birthday:</label>
                        </div>
                        <div class="col-lg-10">
                            <input type="date" name="bday" value="2020-11-25" min="1950-01-01" max="2021-11-25"  class="form-control" value="<?php echo $erow['Birthday']; ?>">
                        </div>
                        <div style="height:10px;"></div>    

                    <div class="row">
                        <div class="col-lg-4">
                            <label style="position:relative; top:7px;">Gender:</label>
                        </div>
                        <div class="col-lg-10">
                            <input type="text" name="sex"  class="form-control" value="<?php echo $erow['Sex']; ?>">
                        </div>
                        <div style="height:10px;"></div>    
                        
                    <div class="row">
                        <div class="col-lg-4">
                            <label style="position:relative; top:7px;">Age:</label>
                        </div>
                        <div class="col-lg-10">
                            <input type="text" name="Age"  class="form-control" value="<?php echo $erow['Age']; ?>">
                        </div>
                        <div style="height:10px;"></div>    
                    </div>

                    <div class="row">
                        <div class="col-lg-4">
                            <label style="position:relative; top:7px;">Mother Tongue:</label>
                        </div>
                        <div class="col-lg-10">
                            <input type="text" name="MotherTongue"  class="form-control" value="<?php echo $erow['MotherTongue']; ?>">
                        </div>
                        <div style="height:10px;"></div>

                    <div class="row">
                        <div class="col-lg-4">
                            <label style="position:relative; top:7px;">Address:</label>
                        </div>
                        <div class="col-lg-10">
                            <input type="text" name="lugar"  class="form-control" value="<?php echo $erow['Address']; ?>">
                        </div>
                        <div style="height:10px;"></div>

                    <div class="row">
                        <div class="col-lg-4">
                            <label style="position:relative; top:7px;">Zip Code:</label>
                        </div>
                        <div class="col-lg-10">
                            <input type="int" name="Zip"  class="form-control" value="<?php echo $erow['ZipCode']; ?>">
                        </div>
                        <div style="height:10px;"></div>        
                        
                    <div class="row">
                        <div class="col-lg-4">
                            <label style="position:relative; top:7px;">Mothers Name</label>
                        </div>
                        <div class="col-lg-10">
                            <input type="text" name="MotherName"  class="form-control" value="<?php echo $erow['MotherName']; ?>">
                        </div>
                        <div style="height:10px;"></div>    
                    </div>

                    <div class="row">
                        <div class="col-lg-4">
                            <label style="position:relative; top:7px;">Fathers Name:</label>
                        </div>
                        <div class="col-lg-10">
                            <input type="text" name="FatherName"  class="form-control" value="<?php echo $erow['FatherName']; ?>">
                        </div>
                        <div style="height:10px;"></div>

                    </div>
                    <div class="row">
                        <div class="col-lg-4">
                            <label style="position:relative; top:7px;">Telephone Number:</label>
                        </div>
                        <div class="col-lg-10">
                            <input type="text" name="TeleNumber"  class="form-control" value="<?php echo $erow['TelephoneNumber']; ?>">
                        </div>
                        
                    <div class="row">
                        <div class="col-lg-4">
                            <label style="position:relative; top:7px;">Cellphone Number:</label>
                        </div>
                        <div class="col-lg-10">
                            <input type="text" name="CellNumber"  class="form-control" value="<?php echo $erow['CellphoneNumber']; ?>">
                        </div>
                        <div style="height:10px;"></div>    
                    </div>
                </div> 
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-dark" data-dismiss="modal"><span class="glyphicon glyphicon-remove"></span> Cancel</button>
                    <button type="submit" class="btn btn-warning"><span class="glyphicon glyphicon-check"></span> Save</button>
                </div>
                </form>
            </div>
        </div>
    </div>
<!-- /.modal -->

<!-- /.modal -->