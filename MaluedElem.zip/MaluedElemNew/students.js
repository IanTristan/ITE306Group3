var search_input = document.querySelector("#search_input");

search_input.addEventListener("keyup", function(e){
  var span_students = document.querySelectorAll(".table_body .name span");
  var table_body = document.querySelector(".table_body ul");
  var search_students = e.target.value.toLowerCase();
 
 span_students.forEach(function(student){
   if(student.textContent.toLowerCase().indexOf(search_students) != -1){
      student.closest("li").style.display = "block";
   }
   else{
     student.closest("li").style.display = "none";
     }
 })
  
});