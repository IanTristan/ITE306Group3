<?php include "includes/config.php";

session_start();

if(isset($_SESSION['username'])){
$username = $_SESSION['username'];
 

    if($username){
        if(isset($_POST['change'])){
            $current_pass= mysqli_escape_string($con, $_POST['current_pass']);
            $new_pass = mysqli_escape_string($con,$_POST['psw']);
            $hash_password = password_hash($new_pass, PASSWORD_DEFAULT);
            //connect db


            $queryget = mysqli_query($con,"SELECT password FROM tbl_useraccounts WHERE employee_id = '$username'" ) or die (mysqli_error());
            $row = mysqli_fetch_assoc($queryget);
            $oldpassword = $row['password'];
            $current_hash = password_verify($current_pass, $oldpassword);

            //check pass

            if($current_pass == $current_hash){
                $querychange = mysqli_query($con,"UPDATE tbl_useraccounts SET password ='$hash_password' WHERE employee_id = '$username'");
                    if($querychange){
                        echo "<script>alert('Password has been changed!');document.location='HomeForAdmin.php'</script>";
                    }
            }
            else{
                echo '<script type="text/javascript">alert("Old password didnt match!");</script>';
            }
 
        }
    }
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>User Accounts</title>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.0/jquery.min.js"></script>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css" />
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.15.1/css/all.css" integrity="sha384-vp86vTRFVJgpjF9jiIGPEEqYqlDwgyBgEF109VFjmqGmIY/Y4HV4d3Gp2irVfcrp" crossorigin="anonymous">
    <style>
        * 
        {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            list-style: none;
            font-family: "Monsterrat", sans-serif;
        }

        body, html, p, li 
        { 
            font-family: "Montserrat", sans-serif; 
            background-color: #151515;
        }

        p, li 
        { 
            line-height: 1.8; 
        }

        .main-nav
        {
            float: right;
            list-style: none;
            margin-top: 30px;
        }

        .main-nav li
        {
            display: inline-block;
        }

        .main-nav li a
        {
            color: #f0f8ff;
            background-color: #151515;
            text-decoration: none;
            padding: 5px 20px;
            font-family: "Montserrat", sans-serif; 
            font-size: 15px;
            font-weight: bold;
        }

        .main-nav li.active a 
        {
            background-color: #e8175d;
            color: #f0f8ff;
            border: 2px solid #151515;
        }

        a:hover 
        {
            border: 2px solid #f0f8ff;
        }

        .main-nav li ul{
            margin: 0;
            padding: 0;
            list-style: none;
            position: absolute;
            float: left;
            display: none;
            background-color: #151515;
            width: 106px;  
        }

        .main-nav li ul li{
            display: block;
            float: none;
            margin-bottom: 0px;
            padding: 0;
            margin: 0;
        }

        .main-nav li:hover ul{
            display: block;
        }

        body 
        {
            font-family: monospace;
        }

        .row 
        {
            max-width: 1200px;
            margin: auto;
        }

        .button 
        {
            margin-top: 30px;
            text-align: center;
            margin-bottom: 30px;
        }

        .btn 
        {
            border: 1px solid #151515;
            padding: 10px 30px;
            color: white;
            text-decoration: none;
            margin-right: 5px;
            font-size: 13px;
            text-transform: uppercase;
            display: inline-block;  
        }

        .clearfix:after 
        {
            visibility: hidden;
            display: block;
            font-size: 0;
            content: " ";
            clear: both;
            height: 0;
        }

        .clearfix 
        { 
            display: inline-block; 
        }
            /* start commented backslash hack \*/
        * html .clearfix 
        { 
            height: 1%; 
        }
            
        .clearfix 
        { 
            display: block; 
        }
            /* close commented backslash hack */

        .container 
        {
            width: 100%; 
            max-width: 1200px; 
            margin: 0 auto;
        }

        #main-header 
        { 
            padding-top: 20px; 
        }


        .text-center 
        { 
            text-align: center; 
        }

        p 
        { 
            font-size: 16px; 
            margin-bottom: 20px; 
        }

        ul 
        { 
            padding-left: 40px; 
        }

        ul li 
        { 
            font-size: 16px; 
            margin-bottom: 20px; 
        }

        figure 
        { 
            width: 100% !important; 
            max-width: 100%; 
            text-align: center; 
            font-size: 12px; 
        }

        .form-group{
            margin: 0;
            font-weight: bolder;
        }

        #left{
            float: left;
            width: 75px;
            overflow: hidden;
            padding-top: 10px;
        }


        #midname{
            margin-bottom: 10px;
        }

        #gradelevel{
            float: left;
            overflow: hidden;
        }

        input {
            width: 100%;
            padding: 12px;
            border: 1px solid #ccc;
            border-radius: 4px;
            box-sizing: border-box;
            margin-top: 6px;
            margin-bottom: 16px;
        }

        /* Style the submit button */
        input[type=submit] {
            background-color: #4CAF50;
            color: white;
        }

        /* Style the container for inputs */
        /*.container {
        background-color: #f1f1f1;
        padding: 20px;
        }
        */
        /* The message box is shown when the user clicks on the password field */

        #message {
            display:none;
            background: #f1f1f1;
            color: #000;
            position: relative;
            padding: 20px;
            margin-top: 10px;
        }

        #message p {
            padding: 10px 35px;
            font-size: 18px;
        }

        /* Add a green text color and a checkmark when the requirements are right */

        .valid {
            color: green;
        }

        .valid:before {
            position: relative;
            left: -35px;
            content: "✔";
        }

        /* Add a red text color and an "x" when the requirements are wrong */
        .invalid {
            color: red;
        }

        .invalid:before {
            position: relative;
            left: -35px;
            content: "✖";
        }

    </style>
</head>
<body style="background-color: #e8175d;">
    <div id="main-header" class="row clearfix">
            <ul class="main-nav">
                <li>
                    <a href="HomeForAdmin.php"> Home </a>
                </li>

                <li>
                    <a href="studentsForAdmin.php"> Students </a>
                </li>

                <li>
                    <a href="subjectsForAdmin.php"> Subjects </a>
                </li>

                <li>
                    <a data-toggle="modal" data-target="#myModal" href="#myModal" class="modal-btn"> Enroll Pupil </a>
                </li>

                <li>
                    <a href=""><?php
                              if(isset($_SESSION['first_name'])){
                                echo 'Welcome'.', '.$_SESSION['last_name'];
                              }
                            ?></a>
                    <ul>
                        <li style="padding-left: 6px; padding-bottom: 10px;"><a href="#">History</a></li>
                        <li class="active" style="padding-left: 1px; padding-bottom: 10px;"><a href="teachersForAdmin.php">Teachers</a></li>
                        <li style="padding-left: 10px; padding-bottom: 10px;"><a href="#">About</a></li>
                        <li style="padding-left: 2px; padding-bottom: 10px;"><a data-toggle="modal" data-target="#EditPassword" href="#EditPassword" class="modal-btn">Settings</a></li>
                        <li style="padding-left: 6px; padding-bottom: 10px;"><a href="logout.php" name="logout"> Logout </a></li>
                    </ul>
                </li>
            </ul>
        </div>

        <div class="container" style="background-color: #151515; width: 69%; position: absolute; top: 20%; left: 9%; height: 50%;">
            <div style="height:50px;"></div>
            <div class="well" style="margin:auto; padding:auto; width:120%; background-color: #e8175d; border: 10px solid #151515;">
            	<span class="pull-right"><a href="#addnewsubject" data-toggle="modal" class="btn btn-primary"><span class="glyphicon glyphicon-plus"></span> Add New</a></span>
				<div style="height:50px;"></div>
                <table class="table table-striped table-bordered table-hover" style="align-items: center; width: 100%; background-color: #e8175d; color: #f0f8ff; border: 5px solid #151515; text-align: center; font-family: 'Monsterrat',sans-serif; font-weight: bold;">
                    <thead>
                        <th style="border: 5px solid #151515; text-align: center; width: 15%; padding-bottom: 8px;">Subject Code</th>
                        <th style="border: 5px solid #151515; text-align: center; width: 58%;">Subject Name</th>
                        <th style="border: 5px solid #151515; text-align: center; width: 78%; padding-bottom: 10px;">Assigened Teacher</th>
                        <th style="border: 5px solid #151515; text-align: center; width: 80%; padding-bottom: 10px;">Sectiion</th>
                        <th style="border: 5px solid #151515; text-align: center; width: 80%; padding-bottom: 10px;">GradeLevel</th>
                        <th style="border: 5px solid #151515; text-align: center; width: 80%; padding-bottom: 10px;">Action</th>
                    </thead>

                    <tbody>
                        <?php
                        

                        $query=mysqli_query($con,"SELECT * FROM `tbl_subjects`");
                        while($row=mysqli_fetch_array($query)){
                        ?>

                        <tr style="background-color: #e8175d; border: 5px solid #474747;">
                            <td style="border: 5px solid #151515; padding-top: 15px;"><?php echo $row['SubjectCode']; ?></td>
                            <td style="border: 5px solid #151515; padding-top: 15px;"><?php echo $row['SubjectName']; ?></td>
                            <td style="border: 5px solid #151515; padding-top: 15px;"><?php echo $row['AssigenedTeacher']; ?></td>
                            <td style="border: 5px solid #151515; padding-top: 15px;"><?php echo $row['Section']; ?></td>
                            <td style="border: 5px solid #151515; padding-top: 15px;"><?php echo $row['GradeLevel']; ?></td>


                            

                            
                            <td style="border: 5px solid #151515;">
                               
                                <a href="#deleltesubject<?php echo $row['id']; ?>" data-toggle="modal" class="btn btn-danger"><span class="glyphicon glyphicon-trash"></span> Delete</a>
                            <?php include('buttonsubject.php'); ?>
                            </td>
                        </tr>
                        <?php
                    }

                    ?>
                </tbody>
            </table>
        </div>
        <?php include('add_modalsubject.php'); ?>
    </div>
</body>
</html>

<div class="modal fade" id="EditPassword">
    <form action="" method="post">
        <div class="modal-dialog" role="document">
            <div class="modal-content" style="background-color: #151515; width: 130%; position: absolute; top: 15%; left: -15%;">
                <div class="modal-header" style="border: 3px solid #E4008A;">
                    <center>
                        <h1 style="color: #E4008A; font-weight: bold; font-family: 'Monsterrat',sans-serif;">Change Password</h1>
                    </center>
                </div>

                <div class="modal-body" style="border: 2px solid #E4008A; overflow: auto;">
                    <form method="POST" class="form-body">
                        <div>
                            <div class="form-group" style="display: inline-block; color: #E4008A;">
                                <label style="float: left; margin-left: 200px; margin-top: 10px; margin-right: 5px; font-family: 'Monsterrat', sans-serif;">Current Password</label>
                                <input type="password" name="current_pass" class="form-control" style="width: 30%;">
                            </div>
                        </div>

                        <div>
                            <div class="form-group" style="display: inline-block; color: #E4008A;">
                                <label style="float: left; margin-left: 200px; margin-top: 10px; margin-right: 26px; font-family: 'Monsterrat', sans-serif;">New Password</label>
                                <input type="password" id="psw" name="psw" pattern="(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{8,}" title="Must contain at least one number and one uppercase and lowercase letter, and at least 8 or more characters" required style="width: 30%; padding: 6px; padding-left: 10px;">
                            </div>

                            <div class="form-group" align="center">
                                <input class="btn btn-primary" type="submit" name="change" value ="Save Changes">
                            </div>

                            <div id="message">
                                <h6>Password must contain the following:</h6>
                                <p style="background-color: white;" id="letter" class="invalid">A <b>lowercase</b> letter</p>
                                <p style="background-color: white;" id="capital" class="invalid">A <b>capital (uppercase)</b> letter</p>
                                <p style="background-color: white;" id="number" class="invalid">A <b>number</b></p>
                                <p style="background-color: white;" id="length" class="invalid">Minimum <b>8 characters</b></p>
                            </div>

                            <script>
                                var myInput = document.getElementById("psw");
                                var letter = document.getElementById("letter");
                                var capital = document.getElementById("capital");
                                var number = document.getElementById("number");
                                var length = document.getElementById("length");

                                // When the user clicks on the password field, show the message box

                                myInput.onfocus = function() {
                                    document.getElementById("message").style.display = "block";
                                }

                                // When the user clicks outside of the password field, hide the message box

                                myInput.onblur = function() {
                                    document.getElementById("message").style.display = "none";
                                }

                                // When the user starts to type something inside the password field
                                myInput.onkeyup = function() {
                                // Validate lowercase letters
                                var lowerCaseLetters = /[a-z]/g;
                                if(myInput.value.match(lowerCaseLetters)) {  
                                    letter.classList.remove("invalid");
                                    letter.classList.add("valid");
                                }

                                else {
                                    letter.classList.remove("valid");
                                    letter.classList.add("invalid");
                                }

                                // Validate capital letters
                                var upperCaseLetters = /[A-Z]/g;
                                if(myInput.value.match(upperCaseLetters)) {  
                                    capital.classList.remove("invalid");
                                    capital.classList.add("valid");
                                } 

                                else {
                                    capital.classList.remove("valid");
                                    capital.classList.add("invalid");
                                }

                                // Validate numbers
                                var numbers = /[0-9]/g;
                                if(myInput.value.match(numbers)) {  
                                    number.classList.remove("invalid");
                                    number.classList.add("valid");
                                } 

                                else {
                                    number.classList.remove("valid");
                                    number.classList.add("invalid");
                                }

                                // Validate length
                                if(myInput.value.length >= 8) {
                                    length.classList.remove("invalid");
                                    length.classList.add("valid");
                                } 

                                else {
                                    length.classList.remove("valid");
                                    length.classList.add("invalid");
                                }
                            }
                        </script>
                    </div>
                </form>
            </div>
        </div>
    </div>
</form>
</div>