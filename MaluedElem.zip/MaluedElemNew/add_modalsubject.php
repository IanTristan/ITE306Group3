<?php include "includes/config.php"; ?>
<!-- Add New -->
    <div class="modal fade" id="addnewsubject" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                    <center><h4 class="modal-title" id="myModalLabel">Add New</h4></center>
                </div>
                <div class="modal-body">
				<div class="container-fluid">
				<form method="POST" action="addnewsubject.php">
					<div class="row">
						<div class="col-lg-4">
							<label class="control-label" style="position:relative; top:7px;">Subject Code:</label>
						</div>
						<div class="col-lg-10">
							<input type="text" class="form-control" name="SubjectCode">
						</div>

						<div class="col-lg-4">
							<label class="control-label" style="position:relative; top:7px;">Subject Name:</label>
						</div>
						<div class="col-lg-10">
							<input type="text" class="form-control" name="SubjectName">
						</div>

						<div class="col-lg-4">
							<label class="control-label" style="position:relative; top:7px;">Assigned Teacher:</label>
						</div>
						<div class="col-lg-10">
								<?php
									echo"<select name='Assign'>";
									$query = "SELECT * FROM tbl_useraccounts";
									$result = mysqli_query($con,$query);
									
											while ($row = mysqli_fetch_array($result)) {
												echo "<option value'". $row['LastName']."'>". $row['LastName']."</option>";
											}
										echo "</select>";	
								?>
							
						</div>

						<div class="col-lg-4">
							<label class="control-label" style="position:relative; top:7px;">Section:</label>
						</div>
						<div class="col-lg-10">
							<select name="sec" style="margin-top: 13px; margin-left: 3px; width: 6%; font-family: 'Monsterrat',sans-serif; border: 3px solid #151515;" >
                                <option value="1" style="font-family: 'Monsterrat',sans-serif;">1</option>
                                <option value="2" style="font-family: 'Monsterrat',sans-serif;">2</option>
                                <option value="3" style="font-family: 'Monsterrat',sans-serif;">3</option>
                                <option value="4" style="font-family: 'Monsterrat',sans-serif;">4</option>
                            </select>
						</div>
						
						<div class="col-lg-4">
							<label class="control-label" style="position:relative; top:7px;">Grade level:</label>
						</div>
						<div class="col-lg-10">
							<select name="glvl" style="margin-top: 13px; margin-left: 3px; width: 6%; font-family: 'Monsterrat',sans-serif; border: 3px solid #151515;" >
                                <option value="1" style="font-family: 'Monsterrat',sans-serif;">1</option>
                                <option value="2" style="font-family: 'Monsterrat',sans-serif;">2</option>
                                <option value="3" style="font-family: 'Monsterrat',sans-serif;">3</option>
                                <option value="4" style="font-family: 'Monsterrat',sans-serif;">4</option>
                                <option value="4" style="font-family: 'Monsterrat',sans-serif;">5</option>
                                <option value="4" style="font-family: 'Monsterrat',sans-serif;">6</option>
                            </select>
						</div>
					</div>
                </div> 
				</div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-default" data-dismiss="modal"><span class="glyphicon glyphicon-remove"></span> Cancel</button>
                    <button type="submit" class="btn btn-primary"><span class="glyphicon glyphicon-floppy-disk"></span> Save</a>
				</form>
                </div>
				
            </div>
        </div>
    </div>
