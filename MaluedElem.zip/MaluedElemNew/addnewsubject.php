<?php
	include('includes/config.php');
	
		$SCode = mysqli_real_escape_string($con,$_POST['SubjectCode']);
		$SName = mysqli_real_escape_string($con,$_POST['SubjectName']);
		$Assign = mysqli_real_escape_string($con,$_POST['Assign']);
		$section = mysqli_real_escape_string($con,$_POST['sec']);
		$gradelvl = mysqli_real_escape_string($con,$_POST['glvl']);

	
	
		
		

		$query = "INSERT INTO tbl_subjects (SubjectCode, SubjectName, AssigenedTeacher, Section, GradeLevel)
	VALUES ('$SCode','$SName','$Assign','$section','$gradelvl')";
		$query_run = mysqli_query($con,$query);
		if ($query_run) {
   		
   			  echo "<script>alert('New Subject Added!');document.location='teachers.php'</script>";

		}
		else{
			echo '<script> alert("ERROR HAS OCCURED"); </script>';
		}

?>