-- phpMyAdmin SQL Dump
-- version 4.9.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Dec 14, 2020 at 08:15 AM
-- Server version: 10.4.8-MariaDB
-- PHP Version: 7.3.11

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `db_maluedelem`
--

-- --------------------------------------------------------

--
-- Table structure for table `tbl_students`
--

CREATE TABLE `tbl_students` (
  `LRN` int(100) NOT NULL,
  `LastName` varchar(100) NOT NULL,
  `FirstName` varchar(100) NOT NULL,
  `MiddleName` varchar(100) NOT NULL,
  `ExtentionName` varchar(100) NOT NULL,
  `Section` varchar(100) NOT NULL,
  `GradeLevel` int(10) NOT NULL,
  `Birthday` date NOT NULL,
  `Sex` varchar(100) NOT NULL,
  `Age` int(10) NOT NULL,
  `MotherTongue` varchar(100) NOT NULL,
  `Address` varchar(300) NOT NULL,
  `ZipCode` int(100) NOT NULL,
  `MotherName` varchar(100) NOT NULL,
  `FatherName` varchar(100) NOT NULL,
  `TelephoneNumber` varchar(100) NOT NULL,
  `CellphoneNumber` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tbl_students`
--

INSERT INTO `tbl_students` (`LRN`, `LastName`, `FirstName`, `MiddleName`, `ExtentionName`, `Section`, `GradeLevel`, `Birthday`, `Sex`, `Age`, `MotherTongue`, `Address`, `ZipCode`, `MotherName`, `FatherName`, `TelephoneNumber`, `CellphoneNumber`) VALUES
(2147483647, 'fd', 'asd', 'qwert', 'jr', '1', 1, '2020-11-25', 'male', 2, '<br /><b>Notice</b>:  Undefined index: MotherTouge in <b>C:\\xampp\\htdocs\\MaluedElemNew\\buttonstudent', 'dfghjm', 23456, 'lkyjuthrg', 'gdhfj', '56565', '6565');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_useraccounts`
--

CREATE TABLE `tbl_useraccounts` (
  `id` int(100) NOT NULL,
  `employee_id` int(100) NOT NULL,
  `password` varchar(100) NOT NULL,
  `usertype` enum('Admin','SuperAdmin','','') NOT NULL,
  `FirstName` varchar(100) NOT NULL,
  `LastName` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tbl_useraccounts`
--

INSERT INTO `tbl_useraccounts` (`id`, `employee_id`, `password`, `usertype`, `FirstName`, `LastName`) VALUES
(1, 0, '$2y$10$lgCHLtLUj0NUKwbqOfKQ0eo5.Wxhb/V4acrNYNu3WI.6xw4x9VgHS', 'Admin', 'Serafin', 'gales'),
(2, 1111, '$2Y$10$GIWIBJICIVLJ7TYNQPLBJERBMLM6IMONLHIZY2D0GVUCM1ZH1SPYC', 'Admin', 'hohohooh', 'lovemoko'),
(14, 1112, '$2y$10$umbAu4MJ10u72ESqCe77iO63BXNTSbvN4Co7vT1Pof6NKsEJTK6oK', 'Admin', 'Veronica', 'canlas'),
(3, 1223, '$2y$10$ByVJROfPGx0CyrVi2/WIGOh7pc7hEaqYF4AWbCvwmYuKWF6UuvVce', 'Admin', 'qweqew', 'ewqewq'),
(5, 2323, '$2y$10$GLLHIbBJMni1XbL11pVRgO/o8H85ApiueN6BV/bPoTvzrBOhSDDOK', 'Admin', 'qweqwe', 'ewqewqewq'),
(6, 3434, '$2Y$10$LBWKAYB3KFBRXVV.UC3ZWUC2ENXGZROGQTFHKJJPDFEIBMGXAHHB6', 'Admin', 'panget', 'lovekita'),
(7, 4545, '$2y$10$ojf49Zlit1ZX6aCHsOB9/OPLuXGtga71Z3Bqs1Cafve9jEhvShWKG', 'Admin', 'sam', 'gales'),
(8, 5555, '$2y$10$L7UMqw.j9q0H1fo44KzTg.f2f3Y9Fe1H5F.sjZw//9t9OV9sQYfdq', 'Admin', 'qweqweqwe', 'qweqweqewqwe'),
(9, 6969, '$2y$10$33m4pW07wO8HHi9U1pDfWuhVwP1pNnr3q0bdMVd/.Yzl8LL2cMU7q', 'Admin', 'Alona', 'Delafuente'),
(10, 8888, '$2y$10$H4/TaJUHkxCFp1UBSseICeu2mWBJ/Mp3YYdWrM8lAgBITKrEdrcCu', 'Admin', 'nicole', 'safiya'),
(11, 11111, '$2y$10$/xLsG916icDnR.anFlXSb.w3mMNow58GGI2FiRXu277js80dxeABa', 'Admin', 'qwert', 'sadsad'),
(12, 11112222, '$2y$10$GOgaWfWGbkTlfL6eX0/EfOr0ESmq1mX3MaFRKsCzBuZb4niMR2aYa', 'Admin', 'Serafin', 'gales'),
(13, 123456789, '$2y$10$bhUgfmfmrHH56Ix4mtENBuXAY6aYHcjIl3IvzVD3bixVDD6HtPrku', 'Admin', 'Serafin', 'love');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tbl_students`
--
ALTER TABLE `tbl_students`
  ADD PRIMARY KEY (`LRN`);

--
-- Indexes for table `tbl_useraccounts`
--
ALTER TABLE `tbl_useraccounts`
  ADD PRIMARY KEY (`employee_id`),
  ADD UNIQUE KEY `unique` (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tbl_useraccounts`
--
ALTER TABLE `tbl_useraccounts`
  MODIFY `id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
